package generic;

public class Statistics {
	
	// TODO add your statistics here
	
	// TODO write functions to update statistics

	public static void printStatistics(String statFile)
	{
		// TODO add code here to print statistics in the output file
	}
}
